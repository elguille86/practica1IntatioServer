insert into tbsolicitudatencion(Id ,oficina ,fecha , personal ,insidencia ) values(?, ?,?,?,?)
